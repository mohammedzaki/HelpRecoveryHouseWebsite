﻿// ******************************************************* add_header

function add_header() {


    var header = document.getElementById('header');
    var header_contents = read_contents(
              "MasterPageContent/Header.html");
    place_in_outerHTML(header, header_contents);


}