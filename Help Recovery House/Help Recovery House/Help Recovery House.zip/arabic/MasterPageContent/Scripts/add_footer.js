﻿// ******************************************************* add_footer

function add_footer() {
    var footer = document.getElementById('header');
    var footer_contents = read_contents(
              "MasterPageContent/Footer.html");
    place_in_outerHTML(footer, footer_contents);
}
