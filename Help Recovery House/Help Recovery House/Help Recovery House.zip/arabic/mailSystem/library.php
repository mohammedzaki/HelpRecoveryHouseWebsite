<?php
error_reporting(0);
define("SMTP_HOST", "mail.eye-egypt.com"); //Hostname of the mail server
define("SMTP_PORT", "587"); //Port of the SMTP like to be 25, 80, 465 or 587
define("SMTP_UNAME", "test@eye-egypt.com"); //Username for SMTP authentication any valid email created in your domain
define("SMTP_PWORD", "testtest"); //Password for SMTP authentication
define("_UNAME", "Mohammed Zaki"); //Password for SMTP authentication
define("_UMAILMZ", "mohammedzaki.dev@gmail.com");
define("_UMAIL1", "info@helprh.com");
define("_UMAIL2", "mkt@helprh.com");
define("_UMAIL3", "aragab@re-view.me");

?>